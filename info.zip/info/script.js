const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

// Toggle Navbar on menu icon click
menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});


const cardContainer = document.getElementById('cardContainer');
        const scrollLeftBtn = document.getElementById('scrollLeft');
        const scrollRightBtn = document.getElementById('scrollRight');
        const icons = document.querySelectorAll('.card .icon');

        scrollLeftBtn.addEventListener('click', () => {
            cardContainer.scrollBy({ left: -300, behavior: 'smooth' });
        });

        scrollRightBtn.addEventListener('click', () => {
            cardContainer.scrollBy({ left: 300, behavior: 'smooth' });
        });

        icons.forEach((icon, index) => {
            icon.addEventListener('click', () => {
                const targetPosition = index * 320;
                const animationDuration = 1000; // Duration in milliseconds
                const startTime = performance.now();

                function animateScroll(currentTime) {
                    const elapsedTime = currentTime - startTime;
                    const progress = Math.min(elapsedTime / animationDuration, 1);
                    const scrollPosition = progress * targetPosition;
                    cardContainer.scrollTo({ left: scrollPosition });

                    if (progress < 1) {
                        requestAnimationFrame(animateScroll);
                    }
                }

                requestAnimationFrame(animateScroll);
            });
        });

        document.getElementById('exchange-btn').addEventListener('click', () => {
            const amount = parseFloat(document.getElementById('amount').value);
            const currency = document.getElementById('currency').value;
            let conversionRate;
          
            switch (currency) {
              case 'usd':
                conversionRate = 1.0; // Example rate
                break;
              case 'eur':
                conversionRate = 0.9;
                break;
              case 'gbp':
                conversionRate = 0.8;
                break;
              default:
                conversionRate = 1.0;
            }
          
            if (isNaN(amount) || amount <= 0) {
              document.getElementById('result').innerText = 'Please enter a valid amount.';
            } else {
              const convertedAmount = (amount * conversionRate).toFixed(2);
              document.getElementById('result').innerText = `Converted amount: ${convertedAmount} ${currency.toUpperCase()}`;
            }
          });
          
