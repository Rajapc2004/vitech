
    gsap.from(".hero-text h5", {
        opacity: 0,
        y: -20,
        duration: 1,
        delay: 0.5
    });

    gsap.from(".hero-text h1", {
        opacity: 0,
        y: -50,
        duration: 1,
        delay: 1
    });

    gsap.from(".hero-text p", {
        opacity: 0,
        y: 20,
        duration: 1,
        delay: 1.5
    });

    gsap.from(".btn-group .btn", {
        opacity: 0,
        y: 20,
        duration: 1,
        delay: 2,
        stagger: 0.3
    });

    gsap.from(".social a", {
        opacity: 0,
        y: 20,
        duration: 1,
        delay: 2.5,
        stagger: 0.2
    });

    // About Section Animations
    gsap.from(".about h1", {
        scrollTrigger: {
            trigger: ".about",
            start: "top 80%"
        },
        opacity: 0,
        y: 50,
        duration: 1
    });

    gsap.from(".about p", {
        scrollTrigger: {
            trigger: ".about",
            start: "top 80%"
        },
        opacity: 0,
        y: 50,
        duration: 1,
        delay: 0.3
    });

    // gsap.from(".workbox", {
    //     scrollTrigger: {
    //         trigger: ".work",
    //         start: "top 80%"
    //     },
    //     opacity: 0,
    //     y: 50,
    //     duration: 1,
    //     stagger: 0.2
    // });

    // Contact Section Animations
    gsap.from(".contactTitle h2", {
        scrollTrigger: {
            trigger: ".con",
            start: "top 80%"
        },
        opacity: 0,
        x: -50,
        duration: 1
    });

    gsap.from(".contactTitle p", {
        scrollTrigger: {
            trigger: ".con",
            start: "top 80%"
        },
        opacity: 0,
        x: -50,
        duration: 1,
        delay: 0.3
    });

    gsap.from(".left .iconGroup", {
        scrollTrigger: {
            trigger: ".left",
            start: "top 80%"
        },
        opacity: 0,
        x: -50,
        duration: 1,
        stagger: 0.2
    });

    gsap.from(".right .messageForm", {
        scrollTrigger: {
            trigger: ".right",
            start: "top 80%"
        },
        opacity: 0,
        x: 50,
        duration: 1
    });

    // General Animations on Load
    gsap.from(".hero-pic img", {
        opacity: 0,
        
        duration: 1,
        delay: 0.5
    });

    // gsap.from(".parallax", {
    //     opacity: 0,
    //     y: 100,
    //     duration: 1,
    //     delay: 0.5
    // });


    
const hamburger = document.querySelector('.hamburger');
const mobileMenu = document.querySelector('.mobile-menu');

hamburger.addEventListener('click', () => {
  mobileMenu.classList.toggle('active');

});






// const menuToggle = document.getElementById('menuToggle');
// const navLinks = document.querySelector('.nav-links');

// menuToggle.addEventListener('click', () => {
//   const isMenuOpen = navLinks.classList.toggle('active');

//   if (isMenuOpen) {
//     gsap.fromTo(
//       navLinks,
//       { opacity: 0, y: -50 },
//       { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out' }
//     );
//   }
// });
var menu = document.querySelector("#nav i")
var cross = document.querySelector("#full i")


var t1 = gsap.timeline({paused:true})

t1.to("#full",{
    right:0,
    duration:0.6
})

t1.from("#full h4",{
    x:150,
    duration:0.6,
    stagger:0.2,
    opacity:0
})

t1.from("#full i",{
    opacity:0
})

t1.pause()

menu.addEventListener("click",function(){
    t1.play()

})

cross.addEventListener("click",function(){
    t1.reverse()
})