gsap.from("#part1 #box",{
    scale:0,
    delay:0.9,
    duration:1,
    rotate:360,
    duration:1,
    scrollTrigger:{
        trigger:"#part1 #box",
        scroller:"body",
        
        start:"top 60%",
        end:"top 30%",
        scrub:1,
        pin:true
    }
    
})

// gsap.from("#part2 #box",{
   // scale:0,

    //duration:2,
    //rotate:360,
// scrollTrigger:{
  //  trigger:"#part2 #box",
    //scroller:"body",
    //markers:true,
    //start:"top 60%"
 //}
//}) 
 gsap.from("#part2 h1",{
    opacity:0,
    duration:2,
    x:500,
    scrollTrigger:{
        trigger:"#part2 h1",
        scroller:"body",
        
        start:"top 50%",
    }

 })

 gsap.from("#part2 h2",{
    opacity:0,
    duration:1,
    x:-500,
    scrollTrigger:{
        trigger:"#part2 h2",
        scroller:"body",
      
        start:"top 50%",

 }
})


gsap.to("page2 h2",{
    transform:"translateX(-150%)",
    scrollTrigger:{
        trigger:"#page2 ",
        scroller:"body",
         marker:true,
         start:"top 0%",
          end:"top -150%",
          scrub:2,
          pin:true

    }
})
















function breakTheText(){
    var h1 = document.querySelector("h2")
    var h1Text = h1.textContent
     // var h1Text = document.querySelector("h1").textContent
    var splittedText = h1Text.split("")
    console.log (splittedText)
    // var halfValue = splittedText.length/2
    var clutter= ""
    // console.log(halfValue)
    splittedText.forEach(function(elem,idx){
        console.log(idx)
        clutter   += `<span class="a"> ${elem}</span>`
    })
    
    h1.innerHTML = clutter
    // console.log(clutter)
    }
     breakTheText()
     gsap.from("h2 span",{
        y:100,
        opacity:0,
        duration:0.8,
        delay:2, 
        stagger:0.15
    })
    






    const bubbleContainer = document.querySelector('.bubble-container');

function createBubble() {
  let bubble = document.createElement('div');
  bubble.classList.add('bubble');
  bubble.style.left = `${Math.random() * 100}vw`;
  bubble.style.width = `${10 + Math.random() * 30}px`;
  bubble.style.height = bubble.style.width;
  bubble.style.animationDuration = `${4 + Math.random() * 6}s`;
  bubbleContainer.appendChild(bubble);

  // Remove bubble after animation ends
  bubble.addEventListener('animationend', () => {
    bubble.remove();
  });
}

// Generate bubbles at intervals
setInterval(createBubble, 300);










window.addEventListener("scroll",function(){
    var header = document.querySelector("header");
    header.classList.toggle("sticky",this.window.scrollY > 0);
})












window.addEventListener('load', function() {

    setTimeout(() => {
        
        document.getElementById('preload').style.opacity = 0;
        document.getElementById('preload').style.transition = 'opacity 1s ease-out';
        
        
        setTimeout(() => {
            document.getElementById('preload').style.display = 'none';
        
            document.getElementById('content').style.display = 'block';
        }, 1000); 
    }, 2000); 
});








function marqueAnimation(){
    window.addEventListener("wheel", function(dets){
        if(dets.deltaY>0){
            
    gsap.to("#logo",{
        transform:'translateX(-200%)',
        delay:1,
        duration:4,
        repeat:-1,
        ease:"none"
    })
    gsap.to("#ar",{
        rotate:180
    })
    
        }
        else{
          
    gsap.to("#ar img",{
        transform:'translateX(0%)',
        delay:1,
        duration:2,
        repeat:-1,
        ease:"none"
    })
    gsap.to("#ar",{
        rotate:0
    })
        }
    })
    
    
    gsap.to("#logo",{
        transform:'translateX(-100%)',
        delay:1,
        duration:2,
        repeat:-1,
        ease:"none"
    })
    
    
    // window.addEventListener("Wheel",function(dets){
    
    // })
    }
    marqueAnimation()

















    // window.addEventListener('load', () => {
    //     // GSAP animation for preloader
    //     gsap.to('#preloader img', {
    //         opacity: 0,
    //         duration: 1,
    //         scale: 0.5, // Shrink the logo as it fades out
    //         onComplete: () => {
    //             // Hide the preloader
    //             document.getElementById('preloader').style.display = 'none';
    
    //             // Show header logo with scaling effect
    //             const headerLogo = document.getElementById('ar').querySelector('img');
    //             gsap.fromTo(headerLogo, 
    //                 { scale: 0.5, opacity: 0 }, 
    //                 { scale: 1, opacity: 1, duration: 1 }
    //             );
    
    //             // Show main content
    //             gsap.to('.content', { opacity: 1, duration: 1, delay: 0.5 });
    //             document.querySelector('.content').style.display = 'block';
    //             document.getElementById('header').style.display = 'block'; // Show the header
    //         }
    //     });
    // });
    
    



    
    


    