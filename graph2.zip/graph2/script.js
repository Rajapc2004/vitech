  // Function to create a pie chart
  function createPieChart(ctx, data, colors) {
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderColor: colors.map(color => color.replace('0.6', '1')),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });
}

// Sample data for the pie charts
const chartData = [
    [12, 19, 3, 5, 2, 3],
    [8, 10, 15, 7, 6, 5],
    [20, 10, 5, 3, 7, 15],
    [6, 14, 8, 10, 5, 7],
    [15, 5, 10, 8, 6, 11],
    [10, 15, 8, 12, 3, 7],
];

const colors = [
    'rgba(255, 99, 132, 0.6)',
    'rgba(54, 162, 235, 0.6)',
    'rgba(255, 206, 86, 0.6)',
    'rgba(75, 192, 192, 0.6)',
    'rgba(153, 102, 255, 0.6)',
    'rgba(255, 159, 64, 0.6)'
];

// Create 6 pie charts

createPieChart(document.getElementById('chart6').getContext('2d'), chartData[5], colors);