

gsap.to(".animated-image", {
    duration: 1.5,
    scale: 1,
    opacity: 1,
    ease: "power3.out",
    delay: 0.5,
  });
  

  gsap.to(".animated", {
    duration: 1.5,
    scale: 1,
    opacity: 1,
    ease: "power3.out",
    delay: 0.5,
  });
  